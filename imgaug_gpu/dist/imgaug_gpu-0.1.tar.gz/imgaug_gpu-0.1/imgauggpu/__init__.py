from .augmenter import Augmenter, AugmenterCPU, ToGPU
from .transforms import Add, Multiply, Grayscale, Dropout, CoarseDropout, ContrastNormalization, GaussianBlur,\
    Sometimes, AdditiveGaussianNoise



# random number cooking ! Is this the best practice ?
